from django.db import models

# Create your models here.

class Subject(models.Model):
	name= models.CharField(max_length=200)
	teacher=models.CharField(max_length=200,default='')

	def  __str__(self):
		return self.name

class Exam(models.Model):
	subject =models.CharField(max_length=200)
	teacher=models.CharField(max_length=200,default=' ')
	question=models.CharField(max_length=200)
	option1=models.CharField(max_length=200)
	option2=models.CharField(max_length=200)
	option3=models.CharField(max_length=200)
	option4=models.CharField(max_length=200)
	answer=models.CharField(max_length=200)

	def __str__(self):
		return self.question

class Result(models.Model):
	studentname = models.CharField(max_length=100)
	subject = models.CharField(max_length=100)
	teacher = models.CharField(max_length=100)
	marks= models.CharField(max_length=100)
	email=models.EmailField(max_length=200,default="")

	def __str__(self):
		return self.studentname