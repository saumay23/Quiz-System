from django.urls import path
from . import views

urlpatterns = 	[
					path('tmain',views.teacherhome,name='tmain'),
					path('smain',views.studenthome,name='smain'),
					path('deletestudent/<str:pk>',views.deletestudent,name='deletestudent'),
					path('mytest',views.mytest,name='mytest'),
					path('deleteexam/<str:pk>',views.deleteexam,name='deleteexam'),
					path('viewexam/<str:pk>',views.viewexam,name='viewexam'),
					path('editexam/<str:pk>',views.editexam,name='editexam'),
					path('createtest',views.createtest,name='createtest'),
					path('createtest/question',views.questionform,name='questionform'),
					path('deletequestion/<str:pk>',views.deletequestion,name='deletequestion'),
					path('startexam/<str:pk>',views.startexam,name='startexam'),
				]