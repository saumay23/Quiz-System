from django.forms import ModelForm
from django import forms
from .models import Exam,Subject

class subject(forms.ModelForm):
	class Meta:
		model = Subject
		fields = '__all__'
