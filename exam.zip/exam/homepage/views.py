from django.shortcuts import render,redirect
from django.contrib import messages
from accounts.models import StudentAccount,TeacherAccount
from .forms import subject
from .models import Subject,Exam,Result
# Create your views here.
def teacherhome(request):
	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		student=StudentAccount.objects.filter(teacher=teacher)
		student_count=student.count()
		context={'session_name':session_name,
				 'student':student,
				 'student_count':student_count,
				}
		return render(request,'homepage/thome.html',context)
	else:
		return redirect('login')

def deletestudent(request,pk):
	student=StudentAccount.objects.get(id=pk)
	studentname=student.name
	teacher=student.teacher.name
	result=Result.objects.filter(studentname=studentname,teacher=teacher,email=student.emailid)
	if request.method == "POST":
		student.delete()
		result.delete()
		return redirect('tmain')
	context={'student':student}
	return render(request,'homepage/deletestudent.html',context)

def createtest(request):
	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		subjectform=subject()
		context={'session_name':session_name,
				 'subjectform' :subjectform
				}
		if request.method == 'POST' and 'next' in request.POST:
			name=request.POST['name']
			if Subject.objects.filter(name=name,teacher =teacher.name).exists():
				messages.error(request,'Subject Already Exists, Please go to Mytest to add question or delete the previous Subject to Create a new one')
			else:
				subjectform=Subject(name=name,teacher=teacher.name)
				request.session['subject']=name
				subjectform.save()
				return redirect('questionform')
		return render(request,'homepage/createtest.html',context)
	else:
		return redirect('login')


def questionform(request):
	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		subname=request.session.get('subject')				
		context={'session_name':session_name,
				 'subname':subname
				}
		if request.method =='POST' and 'add' in request.POST:
			subject=subname
			teachername= teacher.name
			question = request.POST['question']
			option1 =request.POST['option1']
			option2 =request.POST['option2']
			option3 =request.POST['option3']
			option4 =request.POST['option4']
			answer=request.POST['answer']
			if Exam.objects.filter(subject=subject , teacher=teachername,question=question).exists():
				messages.error(request,'Question Already Exists')
				redirect('questionform')
			else:
				exam = Exam(subject=subject,
							teacher=teachername,
							question=question,
							option1=option1,
							option2=option2,
							option3=option3,
							option4=option4,
							answer=answer
							)
				exam.save()
				messages.success(request,'Question Successfully Added')
				redirect('questionform')

		return render(request,'homepage/questionform.html',context)
	else:
		return redirect('login')

def mytest(request):
	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		activetest=Subject.objects.filter(teacher=teacher.name)
		context={'session_name':session_name,
				 'activetest' : activetest,
				}
		return render(request,'homepage/mytest.html',context)
	else:
		return redirect('login')



def deleteexam(request,pk):
	session_name = request.session.get('email')
	teacher=TeacherAccount.objects.get(emailid=session_name)
	examdelete=Subject.objects.get(id=pk)
	questions=Exam.objects.filter(subject=examdelete,teacher=teacher.name)
	result= Result.objects.filter(subject=examdelete,teacher=teacher.name)
	if request.method == 'POST':
		questions.delete()
		examdelete.delete()
		result.delete()
		return redirect('mytest')
	return render(request,'homepage/deleteexam.html')

def viewexam(request,pk):
	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		examname=Subject.objects.get(id=pk)
		result=Result.objects.filter(subject=examname,teacher=teacher.name)
		context={'session_name':session_name,
				 'result':result
				}

		return render(request,'homepage/viewexam.html',context)
	else:
		return redirect('login')

def editexam(request,pk):

	if request.method == 'POST' and 'logout' in request.POST:
		request.session.clear()
	session_name = request.session.get('email')

	
	if session_name:
		teacher=TeacherAccount.objects.get(emailid=session_name)
		session_name=teacher.name.upper()
		examname=Subject.objects.get(id=pk)
		questions=Exam.objects.filter(subject=examname,teacher=teacher.name)
		request.session['subject']=examname.name
		context={'session_name':session_name,
				 'questions':questions
				}

		return render(request,'homepage/editexam.html',context)
	else:
		return redirect('login')

def deletequestion(request,pk):
	questions=Exam.objects.get(id=pk)
	subject=questions.subject
	pk = Subject.objects.only('id').get(name=subject).id
	url= '/homepage/editexam/'+str(pk)
	if request.method == 'POST' and 'delete' in request.POST:
		questions.delete()
		return redirect(url)
	elif request.method == 'POST' and 'cancel' in request.POST:
		return redirect(url)
	return render(request,'homepage/deletequestion.html')

def studenthome(request):
	if request.method=='POST' and 'logout' in request.POST:
		request.session.clear()
		
	session_name = request.session.get('name')
	if session_name :
		
		student= StudentAccount.objects.get(name=session_name)
		session_name=student.name.upper()
		teachername= student.teacher.name.upper()
		teacher =  TeacherAccount.objects.get(name=teachername.lower())
		activetest=Subject.objects.filter(teacher=teacher.name)
		context = {'session_name':session_name,
				   'teacher':teachername,
				   'activetest':activetest,
				  }
		return render(request,'homepage/shome.html',context)
	else:
		return redirect('login')


def startexam(request,pk):
	session_name = request.session.get('name')
	if session_name:
		examname=Subject.objects.get(id=pk)
		student= StudentAccount.objects.get(name=session_name)
		teachername= student.teacher.name.upper()
		teacher =  TeacherAccount.objects.get(name=teachername.lower())
		questions=Exam.objects.filter(subject=examname,teacher=teacher)
		studentname=student.name
		email=student.emailid
		subject=examname
		if Result.objects.filter(studentname=studentname,teacher=teacher,email=email,subject=subject).exists():
			return render(request,"homepage/thankyouform.html")
		elif request.method =='POST' and 'score' in request.POST:
			marks= request.POST['score']
			result = Result(studentname=studentname,teacher=teacher,subject=subject,marks=marks,email=email)
			result.save()
			return render(request,"homepage/thankyouform.html")
		context={'questions':questions,
				}
		return render(request,'homepage/startexam.html',context)
	else:
		return redirect('login')