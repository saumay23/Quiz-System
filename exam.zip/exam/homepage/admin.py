from django.contrib import admin

# Register your models here.
from .models import Exam,Subject,Result

admin.site.register(Exam)
admin.site.register(Subject)
admin.site.register(Result)