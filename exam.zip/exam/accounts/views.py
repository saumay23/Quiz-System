from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import StudentAccountCreation,TeacherAccountCreation
from .models import TeacherAccount,StudentAccount,College
# Create your views here.

def login(request):
	if request.method=='POST':
		emailid=request.POST['emailid']
		password=request.POST['password']
		accounttype=request.POST['accounttype']
		if accounttype == "Student":
			if StudentAccount.objects.filter(emailid=emailid,password=password).exists():
				studentname=StudentAccount.objects.get(emailid=emailid)
				studentname=studentname.name
				request.session['name']=studentname
				return redirect('smain')
			else:
				messages.error(request,'Incorrect Email or password')
				return redirect('login')
		else:
			if TeacherAccount.objects.filter(emailid=emailid,password=password).exists():
				request.session['email']=emailid
				return redirect('tmain')
			else:
				messages.error(request,'Incorrect Email or password')
				return redirect('login')

	return render(request, 'accounts/login.html')

def register(request):
				
	return render(request, 'accounts/register.html')

def studentregister(request):
	studentform = StudentAccountCreation()
	context = {'studentform':studentform}
	if request.method == 'POST':
		name= request.POST['name']
		college=request.POST['college']
		teacher=request.POST['teacher']
		emailid=request.POST['emailid']
		password=request.POST['password']
		college=College.objects.get(id=college)
		teacher=TeacherAccount.objects.get(id=teacher)
		if StudentAccount.objects.filter(emailid=emailid).exists():
			messages.error(request,'Email Already Exists')
			return redirect('studentregister')
		elif TeacherAccount.objects.filter(emailid=emailid).exists():
			messages.error(request,'Email Already exists')
			return redirect('studentregister')
		else:
			studentregister= StudentAccount(name=name,teacher=teacher,emailid=emailid,password=password,college=college)
			studentregister.save()
			messages.success(request,'Successfully Registered')
			return redirect('studentregister')
	return render(request,'accounts/studentregister.html',context)




def teacherregister(request):
	teacherform = TeacherAccountCreation()
	context = {'teacherform':teacherform}
	if request.method == "POST":
		emailid= request.POST.get('emailid')
		if TeacherAccount.objects.filter(emailid=emailid).exists():
			messages.error(request,'Email Already Exists')
			return redirect('teacherregister')
		elif StudentAccount.objects.filter(emailid=emailid).exists():
			messages.error(request,'Email Already Exists')
			return redirect('teacherregister')
		else:
			teacherform=TeacherAccountCreation(request.POST)
			if teacherform.is_valid():
				teacherform.save()
				messages.success(request,'Successfully Registered')
				return redirect('teacherregister')
	else:
		teacherform=TeacherAccountCreation()
	return render(request,'accounts/teacherregister.html',context)





def load_teachers(request):
    college_id = request.GET.get('college')
    teachers = TeacherAccount.objects.filter(college_id=college_id).order_by('name')
    return render(request, 'hr/teachers_dropdown.html', {'teachers': teachers})


	