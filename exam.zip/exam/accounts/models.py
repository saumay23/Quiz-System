from django.db import models

# Create your models here.
class College(models.Model):
	college=models.CharField(max_length=200)

	def __str__(self):
		return self.college



class TeacherAccount(models.Model):
	name=models.CharField(max_length=200)
	emailid=models.EmailField(max_length=200)
	password=models.CharField(max_length=50)
	college=models.ForeignKey(College,on_delete=models.CASCADE)
	
	def __str__(self):
		return self.name


class StudentAccount(models.Model):
	name= models.CharField(max_length=200)
	college= models.ForeignKey(College,on_delete=models.CASCADE)
	teacher=models.ForeignKey(TeacherAccount,on_delete=models.CASCADE)
	emailid=models.EmailField(max_length=200)
	password=models.CharField(max_length=50)
	

	def __str__(self):
		return self.name

