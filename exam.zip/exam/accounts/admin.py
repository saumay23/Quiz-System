from django.contrib import admin

# Register your models here.
from .models import TeacherAccount,StudentAccount,College


admin.site.register(College)
admin.site.register(TeacherAccount)
admin.site.register(StudentAccount)
