from django.forms import ModelForm
from django import forms
from .models import TeacherAccount,StudentAccount

class StudentAccountCreation(ModelForm):
	password = forms.CharField(widget = forms.PasswordInput)
	class Meta:
		model = StudentAccount
		fields = '__all__'

	def __init__(self,*args,**kwargs):
		super().__init__(*args,**kwargs)
		self.fields['teacher'].queryset = TeacherAccount.objects.none()




class TeacherAccountCreation(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput)
	class Meta:
		model = TeacherAccount
		fields = '__all__'
