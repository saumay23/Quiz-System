from django.urls import path
from . import views
urlpatterns = [
    path('',views.login ,name="login"),
    path('register/',views.register,name="register"),
    path('studentregister/',views.studentregister,name="studentregister"),
    path('teacherregister/',views.teacherregister,name="teacherregister"),
 	 path('ajax/load-teachers/', views.load_teachers, name='ajax_load_teachers'),
 	 
]
